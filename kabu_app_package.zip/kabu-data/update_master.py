# -*- coding: utf-8 -*-
"""
銘柄マスター(コード⇔銘柄名)を最新化して data/master.json を更新する。
取得元:
  - 日本株: JPX(日本取引所)公式の上場銘柄一覧 Excel
  - 米国株: NASDAQ Trader 公式のシンボルディレクトリ(NASDAQ + NYSE等)
GitHub Actions 上で実行される。取得に失敗したセクションは既存データを維持する。
"""
import io
import json
import datetime as dt
import urllib.request
from zoneinfo import ZoneInfo

JPX_URL = "https://www.jpx.co.jp/markets/statistics-equities/misc/tvdivq0000001vg2-att/data_j.xls"
US_URLS = [
    "https://www.nasdaqtrader.com/dynamic/symdir/nasdaqlisted.txt",
    "https://www.nasdaqtrader.com/dynamic/symdir/otherlisted.txt",
]
NAME_MAX = 40
PATH = "data/master.json"


def http_get(url, timeout=90):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    return urllib.request.urlopen(req, timeout=timeout).read()


def fetch_jp():
    import pandas as pd
    df = pd.read_excel(io.BytesIO(http_get(JPX_URL)), dtype=str)
    cols = {c: c for c in df.columns}
    code_col = next(c for c in df.columns if "コード" in str(c))
    name_col = next(c for c in df.columns if "銘柄名" in str(c))
    out = {}
    for _, r in df.iterrows():
        code = str(r[code_col]).strip()
        name = str(r[name_col]).strip()
        if not code or code.lower() == "nan" or not name or name.lower() == "nan":
            continue
        out[code] = name[:NAME_MAX]
    if len(out) < 1000:
        raise RuntimeError(f"JPX取得件数が少なすぎます: {len(out)}")
    return out


def fetch_us():
    out = {}
    for url in US_URLS:
        text = http_get(url).decode("utf-8", errors="replace")
        lines = [l for l in text.splitlines() if l and not l.startswith("File Creation")]
        header = lines[0].split("|")
        sym_i = 0
        name_i = header.index("Security Name")
        test_i = header.index("Test Issue") if "Test Issue" in header else None
        for line in lines[1:]:
            f = line.split("|")
            if len(f) <= name_i:
                continue
            if test_i is not None and len(f) > test_i and f[test_i] == "Y":
                continue
            sym, name = f[sym_i].strip(), f[name_i].strip()
            if sym and name and sym not in out:
                out[sym] = name[:NAME_MAX]
    if len(out) < 2000:
        raise RuntimeError(f"米国株取得件数が少なすぎます: {len(out)}")
    return out


def main():
    with open(PATH, encoding="utf-8") as f:
        master = json.load(f)
    old_jp = dict(master.get("jp", []))
    old_us = dict(master.get("us", []))

    try:
        jp = fetch_jp()
        print(f"日本株: {len(jp)}銘柄")
    except Exception as e:
        print(f"WARN 日本株の取得失敗 → 既存{len(old_jp)}件を維持: {e}")
        jp = old_jp
    try:
        us = fetch_us()
        print(f"米国株: {len(us)}銘柄")
    except Exception as e:
        print(f"WARN 米国株の取得失敗 → 既存{len(old_us)}件を維持: {e}")
        us = old_us

    # 取引実績由来の和名など、公式リストにないコードは残す
    for c, n in old_jp.items():
        jp.setdefault(c, n)
    for c, n in old_us.items():
        us.setdefault(c, n)

    now = dt.datetime.now(ZoneInfo("Asia/Tokyo")).isoformat(timespec="seconds")
    out = {"updatedAt": now,
           "jp": sorted([[c, n] for c, n in jp.items()]),
           "us": sorted([[c, n] for c, n in us.items()])}
    with open(PATH, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, separators=(",", ":"))
    print(f"master.json 更新完了: 日本株{len(jp)} / 米国株{len(us)}")


if __name__ == "__main__":
    main()
