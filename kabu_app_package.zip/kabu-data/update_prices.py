# -*- coding: utf-8 -*-
"""
株価・為替・指数を取得し data/prices.json を更新、data/history.json に日次スナップショットを追記する。
GitHub Actions 上で実行される(手元のPCでは実行不要)。
"""
import json
import os
import datetime as dt
from zoneinfo import ZoneInfo

import yfinance as yf

JST = ZoneInfo("Asia/Tokyo")
DATA = "data"


def load(name):
    with open(f"{DATA}/{name}", encoding="utf-8") as f:
        return json.load(f)


def save(name, obj):
    with open(f"{DATA}/{name}", "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, separators=(",", ":"))


def fetch(ticker):
    try:
        t = yf.Ticker(ticker)
        p = None
        try:
            p = getattr(t.fast_info, "last_price", None)
        except Exception:
            p = None
        if p is None or p != p:
            h = t.history(period="5d", auto_adjust=False)
            if len(h):
                p = float(h["Close"].iloc[-1])
        if p is not None:
            return float(p)
    except Exception as e:
        print(f"WARN fetch {ticker}: {e}")
    return fetch_stooq_pair(ticker)[0]           # Yahoo不通時の予備ルート


def fetch_pair(ticker):
    """(最新値, 前日終値) を取得。取れなかった側は None。"""
    last = prev = None
    try:
        t = yf.Ticker(ticker)
        try:
            last = getattr(t.fast_info, "last_price", None)
        except Exception:
            pass
        try:
            prev = getattr(t.fast_info, "previous_close", None)
        except Exception:
            pass
        if last is None or last != last or prev is None or prev != prev:
            h = t.history(period="7d", auto_adjust=False)
            closes = list(h["Close"]) if len(h) else []
            if last is None or last != last:
                last = closes[-1] if closes else None
            if (prev is None or prev != prev) and len(closes) >= 2:
                prev = closes[-2]
    except Exception as e:
        print(f"WARN fetch {ticker}: {e}")
    if last is None or prev is None:
        s_last, s_prev = fetch_stooq_pair(ticker)   # Yahoo不通・欠損時の予備ルート
        last = last if last is not None else s_last
        prev = prev if prev is not None else s_prev
    return (float(last) if last is not None else None,
            float(prev) if prev is not None else None)


def to_stooq_symbol(ticker):
    """YahooティッカーをStooqシンボルに変換。"""
    m = {"USDJPY=X": "usdjpy", "^N225": "^nkx", "^GSPC": "^spx",
         "^IXIC": "^ndq", "^DJI": "^dji"}
    if ticker in m:
        return m[ticker]
    if ticker.endswith(".T"):
        return ticker[:-2].lower() + ".jp"
    return ticker.lower() + ".us"


def fetch_stooq_pair(ticker):
    """Stooqから(最新終値, 前日終値)を取得する予備ルート。失敗時は(None, None)。"""
    import urllib.request
    sym = to_stooq_symbol(ticker)
    url = f"https://stooq.com/q/d/l/?s={sym}&i=d"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        text = urllib.request.urlopen(req, timeout=30).read().decode("utf-8", "replace")
        lines = [l for l in text.strip().splitlines() if l]
        if len(lines) < 2 or not lines[0].lower().startswith("date"):
            return None, None
        closes = []
        for l in lines[1:]:
            f = l.split(",")
            if len(f) >= 5:
                try:
                    closes.append(float(f[4]))
                except ValueError:
                    pass
        if len(closes) >= 2:
            print(f"stooqフォールバック {ticker}({sym}) -> {closes[-1]}")
            return closes[-1], closes[-2]
        if len(closes) == 1:
            return closes[0], None
    except Exception as e:
        print(f"WARN stooq {ticker}: {e}")
    return None, None


def is_usd(account):
    return account in ("moomoo", "Moo", "SBI米")


def fetch_extended(ticker):
    """米国株の時間外込み最新価格を取得。
    戻り値: (価格, フェーズ)。フェーズは "pre"(プレ) / "post"(アフター) / None(通常取引中 or 取得不可)。"""
    try:
        t = yf.Ticker(ticker)
        h = t.history(period="1d", interval="1m", prepost=True, auto_adjust=False)
        if len(h) == 0:
            return None, None
        ts = h.index[-1]
        try:
            ny = ts.tz_convert(ZoneInfo("America/New_York"))
        except Exception:
            return None, None
        px = float(h["Close"].iloc[-1])
        tm = ny.time()
        if dt.time(9, 30) <= tm < dt.time(16, 0):
            return px, None            # 通常取引中
        return px, ("pre" if tm < dt.time(9, 30) else "post")
    except Exception as e:
        print(f"WARN extended {ticker}: {e}")
        return None, None


def backfill_indices(hist):
    """履歴に欠けている指数を過去に遡って記入する。
    米国指数は同日規約(D日の行=米国D日終値)のため、直近7日分は毎回再照合して確定値に訂正する。"""
    targets = {"nikkei": "^N225", "sp500": "^GSPC", "nasdaq": "^IXIC", "dow": "^DJI"}
    recent_cut = (dt.datetime.now(JST).date() - dt.timedelta(days=7)).isoformat()
    for field, tick in targets.items():
        if field != "nikkei":
            for r in hist:
                if r["date"] >= recent_cut:
                    r[field] = None          # 再照合対象
        missing = [r for r in hist if r.get(field) is None]
        if not missing:
            continue
        try:
            h = yf.Ticker(tick).history(period="3y", auto_adjust=False)
            closes = [(ts.date().isoformat(), float(c))
                      for ts, c in zip(h.index, h["Close"])]
        except Exception as e:
            print(f"WARN backfill {tick}: {e}")
            continue
        n = 0
        for r in missing:
            d = r["date"]
            # 同日規約: 米国市場のD日終値は日本のD日の行に記録(確定は翌朝)
            vals = [c for cd, c in closes if cd <= d]
            if vals:
                r[field] = round(vals[-1], 2)
                n += 1
        print(f"backfill {field}: {n}行を補完")


def backfill_stock_prices(hist, trades, today, today_prices, refetch_from=""):
    """銘柄別の日次株価(stock_prices.json)を蓄積・過去補完する。"""
    try:
        sp = load("stock_prices.json")
    except Exception:
        sp = {"byDate": {}}
    by = sp.setdefault("byDate", {})
    # 同日規約への自己修復: 直近7日分の米国株終値は毎回取り直して確定値に訂正
    recent_cut = (dt.date.fromisoformat(today) - dt.timedelta(days=7)).isoformat()
    usd_codes = {str(t["code"]) for t in trades if is_usd(t.get("account"))}
    for d, day in by.items():
        if d >= recent_cut:
            for c in list(day.keys()):
                if c in usd_codes:
                    del day[c]
    if refetch_from:
        cleared = [d for d in by if d >= refetch_from]
        for d in cleared:
            by[d] = {}
        print(f"再取得指定: {refetch_from}以降 {len(cleared)}日分をクリア")
    # 当日: 日本株はライブ(=引け後は終値)をシード。米国株は同日終値が未確定のため
    #        backfill(直近営業日の暫定値)に委ね、翌朝の再照合で確定値に置き換わる
    jp_today = {c: v for c, v in today_prices.items() if c not in usd_codes}
    by.setdefault(today, {}).update(jp_today)
    # 各履歴日の保有銘柄のうち、価格未記録のものを洗い出す
    need = {}
    for r in hist:
        d = r["date"]
        day = by.setdefault(d, {})
        for t in trades:
            if not t.get("entryDate"):
                continue
            if t["entryDate"] <= d and (not t.get("exitDate") or t["exitDate"] > d):
                code = str(t["code"])
                if code not in day:
                    need.setdefault((code, is_usd(t.get("account"))), set()).add(d)
    cache = {}
    for (code, usd), dates in sorted(need.items()):
        ticker = code if usd else f"{code}.T"
        if ticker not in cache:
            try:
                hh = yf.Ticker(ticker).history(period="3y", auto_adjust=False)
                cache[ticker] = [(ts.date().isoformat(), float(cl))
                                 for ts, cl in zip(hh.index, hh["Close"])]
            except Exception as e:
                print(f"WARN stock backfill {ticker}: {e}")
                cache[ticker] = []
        closes = cache[ticker]
        if not closes:
            continue
        filled = 0
        for d in sorted(dates):
            vals = [c for cd, c in closes if cd <= d]     # 同日規約(日米共通)
            if vals:
                by[d][code] = round(vals[-1], 4)
                filled += 1
        if filled:
            print(f"stock backfill {code}: {filled}日分")
    save("stock_prices.json", sp)
    print(f"stock_prices: {len(by)}日 / {sum(len(v) for v in by.values())}件")


def lc_rate(settings, trades, prices, fx, base_date):
    """アプリと同じロジックで有効LC率を算出。"""
    import calendar
    mode = settings.get("lcMode", "fixed")
    fixed = (settings.get("lcRate") or 5) / 100
    if mode == "fixed":
        return fixed
    def pl(t):
        ex = t.get("exitPrice") if t.get("exitDate") else prices.get(str(t["code"]))
        if ex is None or t.get("entryPrice") is None or not t.get("qty"):
            return None
        v = (ex - t["entryPrice"]) * t["qty"]
        return v * fx if is_usd(t.get("account")) else v
    if mode == "直近1カ月":
        y, m = (base_date.year-1, 12) if base_date.month == 1 else (base_date.year, base_date.month-1)
        cutoff = base_date.replace(year=y, month=m,
                                   day=min(base_date.day, calendar.monthrange(y, m)[1])).isoformat()
        basket = [t for t in trades if t.get("entryDate") and t["entryDate"] > cutoff]
    elif mode == "清算済":
        basket = [t for t in trades if t.get("exitDate")]
    elif mode == "保有":
        basket = [t for t in trades if not t.get("exitDate")]
    else:
        basket = trades
    pls = [v for v in (pl(t) for t in basket) if v is not None]
    wins = [v for v in pls if v > 0]; losses = [abs(v) for v in pls if v <= 0]
    if not pls or not losses or not wins:
        return fixed
    rr = (sum(wins)/len(wins)) / (sum(losses)/len(losses))
    win = len(wins)/len(pls)
    try:
        risk = load("marginal_risk.json")
        rk = next((k for k in risk["rrKeys"] if rr >= k), None)
        wk = next((k for k in reversed(risk["winKeys"]) if win >= k), None)
        if rk is None or wk is None:
            return fixed
        v = risk["values"][risk["rrKeys"].index(rk)][risk["winKeys"].index(wk)]
        return v if v is not None else fixed
    except Exception:
        return fixed


def notify_lc_breach(settings, open_trades, prices, fx, base_date):
    """LC割れをGitHub Issueで通知(設定オン時のみ・新規割れのみ)。"""
    if not settings.get("lcAlert"):
        return
    rate = lc_rate(settings, load("trades.json")["trades"], prices, fx, base_date)
    breached = []
    for t in open_trades:
        p = prices.get(str(t["code"]))
        ep = t.get("entryPrice")
        if p is not None and ep and p < ep * (1 - rate):
            breached.append(t)
    try:
        state = load("alert_state.json")
    except Exception:
        state = {"alerted": []}
    prev = set(state.get("alerted", []))
    now_set = {str(t["code"]) for t in breached}
    new_codes = now_set - prev
    state["alerted"] = sorted(now_set)
    save("alert_state.json", state)
    if not new_codes:
        return
    token = os.environ.get("GITHUB_TOKEN", "")
    repo = os.environ.get("GITHUB_REPOSITORY", "")
    if not token or not repo:
        print("WARN 通知: トークン/リポジトリ情報なし")
        return
    lines = []
    for t in breached:
        if str(t["code"]) not in new_codes:
            continue
        p = prices.get(str(t["code"]))
        sym = "$" if is_usd(t.get("account")) else "¥"
        lines.append(f"- {t['code']} {t.get('name','')}: 現在 {sym}{p} / LCライン {sym}{round(t['entryPrice']*(1-rate),2)} (取得 {sym}{t['entryPrice']})")
    title = f"LC割れ通知: {', '.join(sorted(new_codes))} ({base_date})"
    body = f"LC率 {rate*100:.1f}% を下回りました。\n\n" + "\n".join(lines)
    import urllib.request
    req = urllib.request.Request(
        f"https://api.github.com/repos/{repo}/issues",
        data=json.dumps({"title": title, "body": body}).encode(),
        headers={"Authorization": f"Bearer {token}",
                 "Accept": "application/vnd.github+json",
                 "Content-Type": "application/json"},
        method="POST")
    try:
        urllib.request.urlopen(req, timeout=30)
        print(f"LC割れ通知Issueを作成: {title}")
    except Exception as e:
        print(f"WARN Issue作成失敗: {e}")


def main():
    trades = load("trades.json")["trades"]
    settings = load("settings.json")
    now = dt.datetime.now(JST)

    usdjpy = fetch("USDJPY=X")
    nikkei = fetch("^N225")
    sp500 = fetch("^GSPC")
    nasdaq = fetch("^IXIC")
    dow = fetch("^DJI")

    open_trades = [t for t in trades if not t.get("exitDate")]
    prices = {}
    prev_closes = {}
    session = {}
    for t in open_trades:
        code = str(t["code"])
        if code in prices:
            continue
        usd = is_usd(t.get("account"))
        ticker = code if usd else f"{code}.T"
        p, pc = fetch_pair(ticker)
        # 米国株は時間外(プレ/アフター)価格を優先採用
        if usd:
            ext_px, phase = fetch_extended(ticker)
            if ext_px is not None and phase is not None:
                session[code] = {"phase": phase,
                                 "regular": round(p, 4) if p is not None else None}
                p = ext_px
                print(f"{code} 時間外({phase}) {ext_px} / 通常終値 {session[code]['regular']}")
        if p is not None:
            prices[code] = round(p, 4)
            print(f"{code} ({ticker}) -> {p} (前日終値 {pc})")
        else:
            # 取得失敗時は前回値を引き継ぐ
            old = load("prices.json").get("prices", {})
            if code in old:
                prices[code] = old[code]
                print(f"{code} 据え置き {old[code]}")
        if pc is not None:
            prev_closes[code] = round(pc, 4)

    old = load("prices.json")
    out = {
        "updatedAt": now.isoformat(timespec="seconds"),
        "usdjpy": round(usdjpy, 2) if usdjpy else old.get("usdjpy"),
        "nikkei": round(nikkei, 2) if nikkei else old.get("nikkei"),
        "sp500": round(sp500, 2) if sp500 else old.get("sp500"),
        "nasdaq": round(nasdaq, 2) if nasdaq else old.get("nasdaq"),
        "dow": round(dow, 2) if dow else old.get("dow"),
        "prices": prices,
        "prevClose": prev_closes,
        "session": session,
    }
    save("prices.json", out)

    # ---- 日次スナップショット(同日は上書き=最終実行が有効) ----
    fx = out["usdjpy"] or 0
    evaluation = invested = 0.0
    for t in open_trades:
        p = prices.get(str(t["code"]))
        if p is None or not t.get("qty"):
            continue
        m = fx if is_usd(t.get("account")) else 1
        evaluation += p * t["qty"] * m
        invested += (t.get("entryPrice") or 0) * t["qty"] * m
    realized = 0.0
    for t in trades:
        if t.get("exitDate") and t.get("exitPrice") is not None and t.get("entryPrice") is not None:
            v = (t["exitPrice"] - t["entryPrice"]) * (t.get("qty") or 0)
            realized += v * fx if is_usd(t.get("account")) else v
    capital_gain = realized + settings.get("capitalGainOffset", 0)

    cash = settings.get("cash")
    if cash:   # 口座別余力(v3.3+)
        cash_jpy = sum((v.get("jpy") or 0) for v in cash.values())
        cash_usd = sum((v.get("usd") or 0) for v in cash.values())
    else:      # 旧形式
        cash_jpy = settings.get("cashJpy", 0) or 0
        cash_usd = settings.get("cashUsd", 0) or 0
    row = {
        "date": now.strftime("%Y-%m-%d"),
        "fx": out["usdjpy"],
        "evaluation": round(evaluation, 2),
        "cashJpy": cash_jpy,
        "cashUsd": cash_usd,
        "totalAssets": round(evaluation + cash_jpy + cash_usd * fx, 2),
        "invested": round(invested, 2),
        "capitalGain": round(capital_gain, 2),
        "nikkei": out["nikkei"],
        "sp500": out["sp500"],
        "nasdaq": out["nasdaq"],
        "dow": out["dow"],
    }
    h = load("history.json")
    hist = [r for r in h["history"] if r["date"] != row["date"]]
    hist.append(row)
    hist.sort(key=lambda r: r["date"])
    backfill_indices(hist)
    save("history.json", {"history": hist})
    refetch = os.environ.get("REFETCH_FROM", "").strip()
    # 終値台帳(stock_prices)には正規終値を記録する
    # (時間外採用中の銘柄は session[code]["regular"] を使い、過去日の記録方式と揃える)
    close_prices = dict(prices)
    for code, info in session.items():
        if info.get("regular") is not None:
            close_prices[code] = info["regular"]
    backfill_stock_prices(hist, trades, row["date"], close_prices, refetch_from=refetch)
    try:
        notify_lc_breach(settings, open_trades, prices, out["usdjpy"] or 0, now.date())
    except Exception as e:
        print(f"WARN LC通知処理: {e}")
    print("snapshot:", row)


if __name__ == "__main__":
    main()
